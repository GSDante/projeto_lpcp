# Lpcp



## Para executar:
    
    alex Lexer.x

    ghc analisador.hs
    
    ./analisador